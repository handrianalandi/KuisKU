package com.example.project

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.sql.Time
import java.util.concurrent.TimeUnit
import kotlin.math.log

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [isisoal.newInstance] factory method to
 * create an instance of this fragment.
 */
class isisoal : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private lateinit var adapterS:adapterSoalViewSiswa
    private var arSoal:MutableList<soal> = mutableListOf()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }


    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_isisoal, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var _tvWaktu=view.findViewById<TextView>(R.id.tvWaktu)
        var _btnSubmit=view.findViewById<AppCompatButton>(R.id.btnSubmit)
        val _rvSoal=view.findViewById<RecyclerView>(R.id.rvSoal)
//        val _rgJawaban=view.findViewById<RadioGroup>(R.id.rgJawaban)
        var waktusisa:Long=10000
        var jawaban :MutableList<String> = mutableListOf()

        adapterS= adapterSoalViewSiswa(arSoal)
        adapterS.setOnClickCallback(object :adapterSoalViewSiswa.OnItemClickCallback{
            override fun setJawaban(jawabansoal: String, position: Int) {
                jawaban[position]=jawabansoal
                Log.d("jawaban","soal no:"+(position+1).toString()+" jawaban:"+jawaban[position])
            }
        })




        //testing add data
        for (i in 1..10){
            arSoal.add(soal(i.toString()+".","soal "+i.toString(),"jawaban1 "+i.toString(),
            "jawaban2 "+i.toString(),"jawaban3 "+i.toString(),"jawaban4 "+i.toString()
                ))
        }
        _rvSoal.layoutManager=LinearLayoutManager(activity)
        _rvSoal.adapter=adapterS
        //testing add data

        //get jumlah soal
        var jumlahSoal:Int=adapterS.itemCount
        Log.d("jumlahsoal",jumlahSoal.toString())

        //create string list jawaban
        for(i in 1..jumlahSoal){
            jawaban.add(i.toString())
        }


        //TODO: get jawaban dari tiap soal





        //timer
        waktusisa=100000000
        var waktu= object : CountDownTimer(waktusisa,1000){
            override fun onTick(millisUntilFinished: Long) {
//            Log.d("waktu",_tvWaktu?.text.toString())
                _tvWaktu?.setText("Sisa Waktu: " + getString(R.string.formatted_time,
                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)%60,
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished)%60
                ))
            }

            override fun onFinish() {
                Toast.makeText(activity,"waktu habis",Toast.LENGTH_SHORT).show()
            }
        }
        waktu.start()



        _btnSubmit.setOnClickListener{
            for(i in 1..jumlahSoal){
                Log.d("jawaban ","soal "+i.toString()+" : "+jawaban[i-1])
            }
            waktu.cancel()
        }


    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment isisoal.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            isisoal().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}