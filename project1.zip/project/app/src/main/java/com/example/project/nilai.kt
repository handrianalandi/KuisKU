package com.example.project

data class nilai(
    var kode:String,
    var nilai:Int,
    var nama:String
)
