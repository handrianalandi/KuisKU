package com.example.project

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class adapterViewSoalGuru(private val ListViewSoalGuru:MutableList<soal>) :
    RecyclerView.Adapter<adapterViewSoalGuru.ListViewHolder>()

{
    inner class ListViewHolder(itemView: View):RecyclerView.ViewHolder(itemView)
    {
        var _NomorSoal: TextView =itemView.findViewById(R.id.NomorSoal)
        var _Soal: TextView =itemView.findViewById(R.id.Soal)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): adapterViewSoalGuru.ListViewHolder {
        val view:View= LayoutInflater.from(parent.context)
            .inflate(R.layout.layoutviewsoalguru,parent,false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: adapterViewSoalGuru.ListViewHolder, position: Int) {
        var soal=ListViewSoalGuru[position]
        holder._NomorSoal.setText(soal.nomer)
        holder._Soal.setText(soal.soal)
    }

    override fun getItemCount(): Int {
        return ListViewSoalGuru.size
    }
}