package com.example.project

data class soalGuru(
    var idsoal:String,
    var soal:String,
    var jawaban1:String,
    var jawaban2:String,
    var jawaban3:String,
    var jawaban4:String,
    var jawabanbenar:String,
    var kodeujian:String
)