package com.example.project

data class ujianclass(
    val kode:String,
    val nama:String,
    val uidguru:String,
    val tanggalmulai:String,
    val tanggalselesai:String
)
