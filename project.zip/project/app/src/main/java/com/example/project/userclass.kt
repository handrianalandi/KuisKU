package com.example.project

data class userclass(
    val uid:String,
    val nama:String,
    val isteacher:String,
    val email:String
)
