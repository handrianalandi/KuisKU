package com.example.project

data class ujiansiswaclass(
    val uuid:String,
    val uuidsiswa:String,
    val uuidujian:String,
    val nilai:String
)
