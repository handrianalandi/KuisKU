package com.example.project

data class nilai(
    var kode:String,
    var nilai:String,
    var nama:String
)
