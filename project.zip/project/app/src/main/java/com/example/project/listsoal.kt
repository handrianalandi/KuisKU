package com.example.project

data class listsoal(
    var kode:String,
    var namaujian:String
)
